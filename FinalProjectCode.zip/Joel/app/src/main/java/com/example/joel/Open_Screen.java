package com.example.joel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.List;
//imports for future use on easy permission

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class Open_Screen extends AppCompatActivity  {
    private Button calltts;
    private Button firebase;
    private Button vnote;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen);


        calltts = findViewById(R.id.start);
        calltts.setEnabled(true);
        firebase = findViewById(R.id.button_2);
        firebase.setEnabled(true);
        vnote = findViewById(R.id.voice1);
        vnote.setEnabled(true);
        vnote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startvoice();
            }
        });
        firebase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirebase();
            }
        });
        calltts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open();
            }
        });
    }

    private void open(){

        Intent intent = new Intent(this,MainActivity .class);
        startActivity(intent);

    }


    private void openFirebase(){

        Intent intent = new Intent(this,firebase.class);
        startActivity(intent);

        Toast.makeText(this, "Firebase", Toast.LENGTH_LONG).show();

    }
    private void startvoice(){

        Intent intent = new Intent(this,SpeechToText.class);
        startActivity(intent);

        Toast.makeText(this, "Speech To Text", Toast.LENGTH_LONG).show();

    }
}