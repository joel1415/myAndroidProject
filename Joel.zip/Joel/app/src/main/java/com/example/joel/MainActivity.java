//BY JOEL CARLOS 15464
//THE CLASS BELOW SHOWS THE MAIN JAVA CODE FOR THIS PROJECT

package com.example.joel;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.rtugeek.android.colorseekbar.ColorSeekBar;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;
import net.yslibrary.android.keyboardvisibilityevent.util.UIUtil;

import android.view.View;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

//
//

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private TextToSpeech mTTS;
    private EditText mEditText;
    private SeekBar mSeekBarPitch;
    String speakTextTxt;
    private SeekBar mSeekBarSpeed;
    private Button mButtonSpeak;
    private static final String FILE_NAME = "data.txt";
    private static final String WAVE_NAME = "media.mp3" +
            "";
    HashMap<String, String> myHashRender = new HashMap<String, String>();
    String tempDestFile ;

    public static final String EXTRA_TEXT = "com.example.joel.EXTRA_TEXT";
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private DocumentReference noteRef = db.document("Text/Mytext");
    private EditText url_text;
    private TextView textView;
    // String text;
    //EditText ditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button customButton = findViewById(R.id.custom_button);
        Switch switchEnableButton = findViewById(R.id.switch_enable_button);

        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mButtonSpeak = findViewById(R.id.custom_button);


        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.UK);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                        mButtonSpeak.setEnabled(true);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

        mEditText = findViewById(R.id.edit_text);
        mSeekBarPitch = findViewById(R.id.seek_bar_pitch);
        mSeekBarSpeed = findViewById(R.id.seek_bar_speed);

        mButtonSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speak();
            }
        });
        switchEnableButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    customButton.setEnabled(true);
                } else {
                    customButton.setEnabled(false);
                }
            }
        });
        //this hide the keyboad
        KeyboardVisibilityEvent.setEventListener(this, new KeyboardVisibilityEventListener() {
            @Override
            public void onVisibilityChanged(boolean isOpen) {
                if (isOpen) {
                    Toast.makeText(MainActivity.this, "keyboard opened", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "keyboard hidden", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //color code

        ColorSeekBar colorSeekBar = findViewById(R.id.color_seek_bar);
        colorSeekBar.setOnColorChangeListener(new ColorSeekBar.OnColorChangeListener() {
            @Override
            public void onColorChangeListener(int i, int i1, int i2) {
                mEditText.setTextColor(i2);
            }
        });



    }


//text to speech speak code
    private void speak() {
        String text = mEditText.getText().toString();
        float pitch = (float) mSeekBarPitch.getProgress() / 50;
        if (pitch < 0.1) pitch = 0.1f;
        float speed = (float) mSeekBarSpeed.getProgress() / 50;
        if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);


//once speeking it hides the keyboad

        UIUtil.hideKeyboard(this);
    }

    @Override
    protected void onDestroy() {
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.settings, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        UIUtil.hideKeyboard(this);

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

//I HAVE ADDED CODE BELOW FOR FUTURE DEVELOPMENT
// THIS CODE DOWNLOAD EVERTHING FROM WEBSITE AND READ IT,I DID NOT ADD
//
// IT BECAUSE IT REQURES ME TO ADD 3 MORE CLASSES
        //

      //  public boolean onOptionsItemSelected(MenuItem item) {
        //    int id = item.getItemId();
       // switch (View.generateViewId()){
            //    case R.id.openweb:
                //    try {
                  //      if(!url_text.getText().toString().trim().equalsIgnoreCase("")){
                    //        textView.setText("");
                      //      HttpClient client = new DefaultHttpClient();
                        //    HttpGet request = new HttpGet(url_text.getText().toString());
                            // Get the response
                          //  ResponseHandler<String> responseHandler = new BasicResponseHandler();
                            //String response_str = client.execute(request, responseHandler);
                            //textView.setText(response_str);
                        //}else{
                          //  Toast.makeText(getApplicationContext(), "URL String empty.", Toast.LENGTH_LONG).show();
                        //}
                   // }
                    //catch (Exception e) {
                      //  System.out.println("Some error occured.");
                        //textView.setText(e.getMessage());
                    //}
                    //break;
            //}
            //return super.onOptionsItemSelected(item);


        if (id == R.id.fireb) {
            EditText editText1 = (EditText) findViewById(R.id.edit_text);
            String text = editText1.getText().toString();
            Intent intent = new Intent(this, ViewText_in_another_screen.class);
            intent.putExtra(EXTRA_TEXT, text);

            startActivity(intent);
            return true;
        }
        if (id == R.id.mp3) {
//////////
            String text = mEditText.getText().toString();


            FileOutputStream fos = null;

            try {
                fos = openFileOutput(WAVE_NAME, MODE_PRIVATE);
                fos.write(text.getBytes());

                mEditText.getText().clear();
                Toast.makeText(this, "Saved to " + getFilesDir() + "/" + WAVE_NAME,
                        Toast.LENGTH_LONG).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        mTTS.setLanguage(Locale.getDefault());
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            Toast.makeText(this, "save as wave", Toast.LENGTH_LONG).show();

            return true;
        }

        if (id == R.id.openweb) {
            // Get the URL text.


            String url = "https://www.google.com/";
            float pitch = (float) mSeekBarPitch.getProgress() / 50;
            if (pitch < 0.1) pitch = 0.1f;
            float speed = (float) mSeekBarSpeed.getProgress() / 50;
            if (speed < 0.1) speed = 0.1f;

            mTTS.setPitch(pitch);
            mTTS.setSpeechRate(speed);

            mTTS.speak(url, TextToSpeech.QUEUE_FLUSH, null);

            // Parsing the URI and create the intent.
            Uri webpage = Uri.parse(url);

            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

            // Finding an activity to hand the intent and start that activity.
            if (intent.resolveActivity(getPackageManager()) != null) {


                mTTS.speak(url, TextToSpeech.QUEUE_FLUSH, null);


                startActivity(intent);
            } else
            {
                Log.d("ImplicitIntents", "Can't handle this intent!");
            }
            Toast.makeText(this, "Open web", Toast.LENGTH_LONG).show();
            return true;
        }
        if (id == R.id.share) {
            String txt = mEditText.getText().toString();
            String mimeType = "text/plain";
            ShareCompat.IntentBuilder
                    .from(this)
                    .setType(mimeType)
                    .setChooserTitle("Share This")
                    .setText(txt)
                    .startChooser();
            Toast.makeText(this, "Share", Toast.LENGTH_LONG).show();
            return true;
        }
        if (id == R.id.action_english) {
            mTTS.setLanguage(Locale.ENGLISH);
            Toast.makeText(this, "EGLISH", Toast.LENGTH_LONG).show();
            return true;
        }
//saving to SD-CARD
        if (id == R.id.mp31) {


            speakTextTxt = "TEXT TO SPEECH";
            HashMap<String, String> myHashRender = new HashMap<String, String>();
            myHashRender.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, speakTextTxt);

            String exStoragePath = Environment.getExternalStorageDirectory().getAbsolutePath();
            Log.d("MainActivity", "exStoragePath : "+exStoragePath);
            File appTmpPath = new File(exStoragePath + "/sounds/");
            boolean isDirectoryCreated = appTmpPath.mkdirs();
            Log.d("MainActivity", "directory "+appTmpPath+" is created : "+isDirectoryCreated);
            String tempFilename = "audio.wav";
            tempDestFile = appTmpPath.getAbsolutePath() + File.separator + tempFilename;
            Log.d("MainActivity", "tempDestFile : "+tempDestFile);
            new MySpeech(speakTextTxt);
            return true;
        }


        if (id == R.id.action_chinese) {
            mTTS.setLanguage(Locale.CHINESE);
            Toast.makeText(this, "Chinese", Toast.LENGTH_LONG).show();
            return true;
        }

        if (id == R.id.action_french) {
            mTTS.setLanguage(Locale.FRENCH);
            Toast.makeText(this, "FRENCH", Toast.LENGTH_LONG).show();
            return true;
        }
        if (id == R.id.action_italy) {
            mTTS.setLanguage(Locale.ITALIAN);
            Toast.makeText(this, "ITALIAN", Toast.LENGTH_LONG).show();
            return true;
        }


        if (id == R.id.port) {
            mTTS.setLanguage(Locale.JAPANESE);
            Toast.makeText(this, "JAPANEES", Toast.LENGTH_LONG).show();
            return true;
        }
        if (id == R.id.edit) {
            EditText mEditText = (EditText) findViewById(R.id.edit_text);
            String text = mEditText.getText().toString();
            Intent intent = new Intent(this, Edit_text_Activity.class);
            intent.putExtra(EXTRA_TEXT, text);
            startActivity(intent);
            return true;
        }
//saving the text
        if (id == R.id.save) {
            String text = mEditText.getText().toString();


            FileOutputStream fos = null;

            try {
                fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
                fos.write(text.getBytes());

                mEditText.getText().clear();
                Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FILE_NAME,
                        Toast.LENGTH_LONG).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            Toast.makeText(this, "save", Toast.LENGTH_LONG).show();
            return true;
        }
        //this code shows how texts is load back from extnal storage to the application

        if (id == R.id.load) {
            FileInputStream fis = null;

            try {
                fis = openFileInput(FILE_NAME);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);
                StringBuilder sb = new StringBuilder();
                String text;

                while ((text = br.readLine()) != null) {
                    sb.append(text).append("\n");
                }

                mEditText.setText(sb.toString());

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            Toast.makeText(this, "load", Toast.LENGTH_LONG).show();
            return true;

        }
        //this shows how the texts can be saved direct to firebase
        if (id == R.id.savel) {
            String title = mEditText.getText().toString();
            Map<String, Object> note = new HashMap<>();
            note.put(FILE_NAME, title);
            UIUtil.hideKeyboard(this);
            noteRef.set(note)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(MainActivity.this, "Note saved", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this, "Error!", Toast.LENGTH_SHORT).show();
                            Log.d(TAG, e.toString());
                        }
                    });
            Toast.makeText(this, "saviNg to firebase", Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    class MySpeech implements TextToSpeech.OnInitListener
    {

        String tts;

        public MySpeech(String tts)
        {
            this.tts = tts;
            mTTS = new TextToSpeech(MainActivity.this, this);
        }

        @Override
        public void onInit(int status)
        {
            Log.v("log", "initi");
            int i = mTTS.synthesizeToFile(speakTextTxt, myHashRender, tempDestFile);
            if(i == TextToSpeech.SUCCESS)
            {

                Toast toast = Toast.makeText(MainActivity.this, "Saved "+i,
                        Toast.LENGTH_SHORT);
                toast.show();
            }
            System.out.println("Result : " + i);
        }
    }


}